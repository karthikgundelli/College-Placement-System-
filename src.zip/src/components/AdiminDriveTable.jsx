import React, { useState, useEffect } from 'react';
import './Drives.css';

const AdminDriveTable = () => {
  // Initialize state with drives from localStorage or empty array
  const [drives, setDrives] = useState(() => {
    const savedDrives = localStorage.getItem('placementDrives');
    return savedDrives ? JSON.parse(savedDrives) : [];
  });

  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    id: '',
    companyName: '',
    driveDate: '',
    status: 'open',
    skillsRequired: '',
    logo: ''
  });

  // Save drives to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('placementDrives', JSON.stringify(drives));
  }, [drives]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (editingId) {
      // Update existing drive
      const updatedDrives = drives.map(drive => 
        drive.id === editingId ? { ...formData } : drive
      );
      setDrives(updatedDrives);
    } else {
      // Add new drive
      const newDrive = {
        ...formData,
        id: Date.now().toString() // Simple unique ID
      };
      const updatedDrives = [...drives, newDrive];
      setDrives(updatedDrives);
    }
    
    // Reset form
    setEditingId(null);
    setFormData({
      id: '',
      companyName: '',
      driveDate: '',
      status: 'open',
      skillsRequired: '',
      logo: ''
    });
  };

  const handleEdit = (drive) => {
    setEditingId(drive.id);
    setFormData({
      ...drive,
      driveDate: drive.driveDate.includes('T') ? drive.driveDate.split('T')[0] : drive.driveDate // Format date for input
    });
  };

  const handleDelete = (id) => {
    const updatedDrives = drives.filter(drive => drive.id !== id);
    setDrives(updatedDrives);
  };

  return (
    <div className="drive-management">
      <h2>Manage Placement Drives</h2>
      
      <form onSubmit={handleSubmit} className="drive-form">
        {/* Form fields remain the same */}
        <div className="form-group">
          <label>Company Name:</label>
          <input
            type="text"
            name="companyName"
            value={formData.companyName}
            onChange={handleInputChange}
            required
          />
        </div>
        
        <div className="form-group">
          <label>Drive Date:</label>
          <input
            type="date"
            name="driveDate"
            value={formData.driveDate}
            onChange={handleInputChange}
            required
          />
        </div>
        
        <div className="form-group">
          <label>Status:</label>
          <select
            name="status"
            value={formData.status}
            onChange={handleInputChange}
          >
            <option value="open">Open</option>
            <option value="closed">Closed</option>
            <option value="upcoming">Upcoming</option>
          </select>
        </div>
        
        <div className="form-group">
          <label>Skills Required:</label>
          <input
            type="text"
            name="skillsRequired"
            value={formData.skillsRequired}
            onChange={handleInputChange}
          />
        </div>
        
        <div className="form-group">
          <label>Logo URL:</label>
          <input
            type="text"
            name="logo"
            value={formData.logo}
            onChange={handleInputChange}
          />
        </div>
        
        <button type="submit" className="submit-btn">
          {editingId ? 'Update Drive' : 'Add Drive'}
        </button>
        {editingId && (
          <button
            type="button"
            className="cancel-btn"
            onClick={() => {
              setEditingId(null);
              setFormData({
                id: '',
                companyName: '',
                driveDate: '',
                status: 'open',
                skillsRequired: '',
                logo: ''
              });
            }}
          >
            Cancel
          </button>
        )}
      </form>
      
      <div className="drive-table-container">
        <table className="drive-table">
          <thead>
            <tr>
              <th>Company</th>
              <th>Date</th>
              <th>Status</th>
              <th>Skills</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {drives.map((drive) => (
              <tr key={drive.id}>
                <td>
                  {drive.logo && (
                    <img src={drive.logo} alt={drive.companyName} className="company-logo" />
                  )}
                  {drive.companyName}
                </td>
                <td>{new Date(drive.driveDate).toLocaleDateString()}</td>
                <td>
                  <span className={`status-badge ${drive.status}`}>
                    {drive.status}
                  </span>
                </td>
                <td>{drive.skillsRequired}</td>
                <td>
                  <button
                    onClick={() => handleEdit(drive)}
                    className="edit-btn"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(drive.id)}
                    className="delete-btn"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminDriveTable;