import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { useState } from 'react';
import Home from './pages/Home';
import About from './pages/About';
import Contact from './pages/Contact';
import Navbar from './components/Navbar';
import AptitudeTest from './components/AptitudeTest';
import ResumeBuilder from './components/ResumeBuilder';
import AptitudePractice from './components/AptitudePractice';
import NewPage from './components/NewPage';
import UserDriveTable from './components/UserDriveTable';
import AdminDriveTable from './components/AdiminDriveTable';
import MockInterviewPage from './pages/MockInterview';

const App = () => {
  // State to toggle between admin and user views for drive tables
  const [isAdmin, setIsAdmin] = useState(true);

  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/aptitude" element={<AptitudeTest />} />
        <Route path="/who-are-we" element={<NewPage />} />
        <Route path="/resume" element={<ResumeBuilder />} />
        <Route path="/drives" element={<UserDriveTable />} />
        <Route path="/interview" element={< MockInterviewPage />} />
        <Route path="/aptitude/:company" element={<AptitudePractice />} />
        <Route path="/admin" element={<AdminDriveTable />} />
        
        {/* Drive Tables Route - You might want to put this under a specific path */}
        <Route path="/drive" element={
          <div className="App">
            <button onClick={() => setIsAdmin(!isAdmin)}>
              Switch to {isAdmin ? 'User' : 'Admin'} View
            </button>
            {isAdmin ?<AdminDriveTable /> : <UserDriveTable />}
          </div>
        } />
      </Routes>
    </Router>
  );
};

export default App;